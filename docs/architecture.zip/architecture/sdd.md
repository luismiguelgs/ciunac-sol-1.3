# Software Design Description (SDD) v1.3

- Ultima actualizacion: 2026-09-01.

## 1. Contexto del sistema
El frontend CIUNAC gestiona procesos academicos y administrativos para postulantes y estudiantes. La aplicacion guia al usuario por formularios multi-step, consulta catalogos, registra solicitudes, envia notificaciones y genera comprobantes consumiendo APIs externas.

```mermaid
flowchart LR
    U[Usuario] --> Browser[Navegador]
    Browser --> FE[Next.js App Router]
    FE --> BFF[Route Handlers BFF]
    BFF --> API[API CIUNAC]
    FE --> Q10[API Q10 server-side]
    BFF --> MAIL[Servicio de correo]
    BFF --> CAPTCHA[Google reCAPTCHA]
    API --> DB[(Persistencia backend)]
```

## 2. Alcance
Este SDD describe la arquitectura del frontend Next.js. El backend, la base de datos y servicios externos se tratan como sistemas integrados mediante contratos HTTP.

La vista completa de arquitectura, con diagramas de contexto, contenedores, capas, datos, estado, integracion y despliegue, se mantiene en `docs/architecture/complete-architecture.md`.

Quedan dentro del alcance:
- flujos de solicitud de certificados;
- solicitud de constancias;
- solicitud de beca;
- examen de ubicacion;
- alumno nuevo;
- consulta y descarga de cargos o constancias;
- estrategia de estado, integracion HTTP y reglas de modulo.

## 3. Arquitectura actual consolidada
- Next.js App Router.
- Componentes cliente con formularios multi-step.
- `shadcn/ui`, React Hook Form y Zod para UI y validacion.
- Zustand para estado efimero de flujos multi-step.
- Infraestructura compartida minima para transporte HTTP, errores y adaptadores
  transversales estables.
- BFF con Route Handlers para credenciales, OTP, CAPTCHA y operaciones protegidas.
- Features principales organizadas por capas internas.
- Vitest para pruebas unitarias e integracion; Playwright para smoke, accesibilidad
  y regresion E2E.
- GitHub Actions con cuatro gates obligatorios y regresion completa programada.

## 4. Arquitectura objetivo
Cada feature principal sigue una arquitectura modular con capas internas:

```text
modules/<feature>/
  presentation/
  application/
  domain/
  infrastructure/
```

```mermaid
flowchart TD
    Route[App Router Page] --> Presentation[Presentation]
    Presentation --> UseCase[Application Use Case]
    UseCase --> Port[Application Port]
    Port --> Gateway[Infrastructure Gateway]
    Gateway --> Http[Shared HTTP Functions]
    Http --> BFF[Next.js BFF]
    BFF --> API[External API]
    UseCase --> Domain[Domain Rules]
```

## 5. Vista logica
### Presentation
- Paginas, componentes de proceso, hooks de submit, loading, dialogos y navegacion.
- Puede usar casos de uso y reglas de dominio.
- No debe construir payloads HTTP ni hablar con `fetch`.

### Application
- Casos de uso y puertos.
- Orquesta pasos como guardar estudiante, registrar solicitud, enviar correo o validar duplicidad.
- No debe depender de React, Next.js, stores ni componentes UI.

### Domain
- Reglas puras y tipos del negocio frontend.
- No conoce transporte, framework, stores ni infraestructura.

### Infrastructure
- Gateways, repositories, DTOs, mappers y clientes de API.
- Implementa puertos definidos por application.

### Shared
- Infraestructura transversal minima, errores, schemas y componentes compartidos.
- Solo recibe piezas que ya tienen uso transversal real.
- No mantiene cache global de catalogos cuando el mismo dato ya fue cargado en un
  Server Component.

## 6. Vista de desarrollo
Patron ya aplicado en:
- `modules/solicitud-certificado`
- `modules/solicitud-beca`
- `modules/solicitud-ubicacion`
- `modules/solicitud-constancia`
- `modules/consultas`
- `modules/consulta-solicitud`
- `modules/consulta-certificado`
- `modules/consulta-ubicacion`

API publica de `consulta-certificado`:
- `@/modules/consulta-certificado`: contrato de presentacion.
- `@/modules/consulta-certificado/server`: consulta cohesiva marcada `server-only`.
- El feature usa un slice vertical simplificado con dominio, contrato externo y
  presentacion; no crea una capa application sin orquestacion real.
- Las rutas y otros features no consumen `domain`, `infrastructure` o
  `presentation` mediante imports profundos.
- `/consulta-certificado/{id}` es una verificacion publica de solo lectura iniciada
  por el QR. No depende de la sesion de `consulta-solicitud`.
- El navegador nunca recibe la API key ni accede directamente al proveedor; la
  consulta y la validacion Zod se ejecutan en servidor. El contrato descarta
  campos desconocidos y verifica que el ID devuelto corresponda al solicitado.

API publica de consultas de solicitudes:
- `@/modules/consultas`: formulario y contratos transversales browser-safe.
- `@/modules/consultas/server`: consulta tipada compuesta en servidor.
- `@/modules/consulta-solicitud`: resultados de certificados y constancias.
- `@/modules/consulta-solicitud/server`: entrada server-only que fija el contexto
  funcional de certificados y constancias.
- `client.tsx` conecta los casos de uso de documentos digitales con su gateway sin
  permitir imports de infraestructura desde presentation.

Formato compartido de cargos:
- `modules/shared/components/administrative-cargo-pdf.tsx` contiene A4, encabezado
  institucional y estilos comunes.
- Certificado, constancia, ubicacion y consulta mantienen sus propios adaptadores,
  titulos, textos y reglas funcionales.

API publica de consulta de ubicacion:
- `@/modules/consulta-ubicacion`: vista y contrato de presentacion.
- `@/modules/consulta-ubicacion/server`: composicion server-only del join.
- Su infraestructura adapta `@/modules/consultas/server` a modelos locales; dominio,
  aplicacion y presentacion no importan otros features.
- El cargo se deriva de la solicitud activa y no realiza una segunda consulta por ID.

API publica de solicitud de beca:
- `@/modules/solicitud-beca`: formulario de verificacion y wizard.
- `@/modules/solicitud-beca/client`: composicion funcional de registro y reintento
  de correo, sin commands, ports o clases gateway de un solo metodo.
- `@/modules/solicitud-beca/server`: catalogos academicos, validacion binaria PDF y
  canonicalizacion server-side de facultad, escuela y periodo.
- El schema Zod es la fuente del DTO externo; el workflow Zustand conserva el ID
  guardado para impedir una segunda persistencia durante el reintento de correo.
- Las rutas y el BFF no importan application, infrastructure o presentation de
  forma profunda.

API publica de solicitud de constancias:
- `@/modules/solicitud-constancia`: wizard y componentes de finalizacion.
- `@/modules/solicitud-constancia/client`: composicion de registro, estudiante,
  correo y cargo.
- `@/modules/solicitud-constancia/server`: catalogos y validacion server-side del
  precio para tipos `5` y `6`.
- App Router y el BFF no importan internals; los catalogos se validan en servidor y
  presentation no consume repositories ni stores globales de catalogos.

API publica de solicitud de ubicacion:
- `@/modules/solicitud-ubicacion`: cronograma, wizard y finalizacion.
- `@/modules/solicitud-ubicacion/client`: composicion de perfil, duplicidad,
  estudiante, registro, correo y cargo.
- `@/modules/solicitud-ubicacion/server`: catalogos, cookie de perfil y validacion
  server-side de payloads y archivos.
- El BFF selecciona el validador PDF academico mediante la sesion `UBICACION` y no
  reutiliza reglas internas de becas.
- Las operaciones de aplicacion son funciones inyectables en `location-operations.ts`,
  no clases ni archivos de ports. El cliente HTTP local concentra estudiantes,
  solicitudes, correo, perfil y cargo; DTOs se infieren de Zod y conservan sus mappers.
- Duplicidad se comprueba en cliente y BFF con la misma regla pura. El BFF exige
  tarifa S/ 30, perfil compatible y nivel basico cuando el usuario no es CIUNAC.
- El formulario descarta busquedas tardias, invalida datos dependientes al cambiar
  identidad y bloquea avances concurrentes. Zustand conserva los pasos y el exito
  parcial de correo; el resumen no vuelve a parsear toda la solicitud durante render.
- La entrada devuelve `requestType`, `texts` y `schedules`, sin consultar idiomas.
  Idiomas se carga al ingresar al proceso. El PDF permanece A4 y diferido.

API publica de solicitud de alumno nuevo:
- `@/modules/solicitud-nuevo`: wizard de tres pasos.
- `@/modules/solicitud-nuevo/client`: composicion de registro Q10 y reintento de
  notificacion.
- `@/modules/solicitud-nuevo/server`: catalogo de programas y validacion
  server-side de DTO, sesion, email y programa.
- App Router, el BFF y seguridad no importan internals del feature; los DTOs de
  respuesta se infieren desde la validacion Zod.

Infraestructura compartida:
- `modules/shared/application/errors/app-error.ts`
- `modules/shared/infrastructure/api/*`
- `modules/shared/infrastructure/validation/external-response.ts`
- `lib/api.service.ts`
- `modules/security/server/*`
- `modules/security/client/security-client.ts`
- `app/api/security/*`
- `app/api/ciunac/[...path]/route.ts`
- `app/api/ciunac/proxy-policy.ts`
- `app/api/ciunac/proxy-validation.ts`

Politica implementada del BFF CIUNAC:

- `app/api/ciunac/proxy-policy.ts` traduce metodo y ruta a una
  operacion cerrada; no existe autorizacion ambigua `either`.
- `app/api/ciunac/proxy-validation.ts` concentra los contratos de transporte y
  delega cada DTO de negocio a la API publica server-only de su feature.
- La sesion OTP autoriza solo su feature: tipos `1..4` para certificados, `5..6`
  para constancias, `7` para ubicacion, becas para `BECA` y Q10 para `NUEVO`.
- Las sesiones OTP y de consulta se descifran una vez por request.
- Estudiantes y becas deben conservar el email verificado; los cargos deben
  conservar el tipo asociado al flujo.
- Catalogos, QR y joins privados se consultan server-side y no forman parte de la
  allowlist del navegador.
- `modules/security` no conoce internals de consultas ni de features de solicitud;
  sus schemas se limitan a OTP, consulta y notificacion.

Estado compartido y de flujo:
- `modules/solicitud-certificado/presentation/solicitud-certificado.store.ts`: workflow tipado de certificados.
- `modules/solicitud-constancia/presentation/solicitud-constancia.store.ts`: borrador exclusivo de constancias.
- `modules/solicitud-beca/presentation/solicitud-beca.store.ts`: workflow tipado de beca.
- `modules/solicitud-nuevo/presentation/new-student.store.ts`: workflow tipado de alumno nuevo.
- `modules/solicitud-ubicacion/presentation/solicitud-ubicacion.store.ts`: workflow tipado de ubicacion.

## 7. Vista de datos
Se distinguen estos modelos:
- `FormModel`: datos capturados por React Hook Form.
- `Command`: entrada del caso de uso.
- `DomainModel`: conceptos de negocio frontend.
- `RequestDTO`: contrato enviado a API.
- `ResponseDTO`: contrato recibido desde API.
- `ViewModel`: shape listo para render o flujo de UI.

```mermaid
flowchart LR
    Form[FormModel] --> Process[Presentation Process]
    Process --> Command[Command]
    Command --> UseCase[Use Case]
    UseCase --> Mapper[Mapper]
    Mapper --> DTO[RequestDTO]
    DTO --> API[API]
```

## 8. Vista de estado
- React Hook Form: estado local de formulario.
- Zustand de flujo: datos que sobreviven entre pasos del wizard.
- Hooks de presentation: loading, submit, mensajes y dialogos.
- Server Components: fuente preferente para catalogos de solo lectura; los datos
  ya resueltos se inyectan a componentes cliente.

## 9. Vista de despliegue
La aplicacion compila como frontend Next.js. Las rutas se generan como contenido
estatico o dinamico segun App Router. GitHub Actions valida cada cambio antes de
su integracion y ejecuta regresion completa en Ubuntu despues del merge.

```mermaid
flowchart TD
    Browser[Navegador] --> Next[Next.js App]
    Next --> Public[Assets publicos]
    Browser --> BFF[Route Handlers BFF]
    BFF --> Api[API CIUNAC]
    BFF --> Mail[Correo]
    BFF --> Captcha[reCAPTCHA]
    Next --> Q10[API Q10]
```

```mermaid
flowchart LR
    Change["Push o pull request"] --> CI["GitHub Actions"]
    CI --> Static["Calidad estatica"]
    CI --> Tests["Unitarias e integracion"]
    CI --> Build["Build y bundle seguro"]
    CI --> Browser["Smoke y axe"]
    Main["main / cron"] --> E2E["Regresion Playwright completa"]
```

Los workflows usan Node.js `24.11.1`, instalacion reproducible con `npm ci` y
variables sinteticas. No contienen secretos reales. Los artefactos de navegador y
auditoria se retienen durante 14 dias.

## 10. Decisiones arquitectonicas
Las decisiones quedan registradas como ADRs en `docs/architecture/adr/`.

ADRs vigentes:
- ADR-001 Mantener Next.js App Router.
- ADR-002 Refactorizar incrementalmente por feature.
- ADR-003 Adoptar capas internas por feature.
- ADR-004 Centralizar HTTP, errores y mappers.
- ADR-005 Definir politica de estado frontend.
- ADR-006 Separar el flujo de constancias.
- ADR-007 Introducir BFF seguro, OTP y CAPTCHA server-side.
- ADR-008 Usar resultados explicitos para operaciones externas.
- ADR-009 Adoptar dominio, workflow y fronteras runtime tipadas para constancias.
- ADR-010 Adoptar un contexto tipado comun para consultas por documento.
- ADR-011 Tipar el detalle de certificado y asociarlo al documento consultado.
- ADR-012 Ejecutar en servidor el join tipado de consulta de ubicacion.
- ADR-013 Adoptar dominio, workflow y documentos PDF seguros para solicitud de beca.
- ADR-014 Adoptar dominio, workflow y validacion server-side de precio para certificados.
- ADR-015 Adoptar dominio, workflow y validacion server-side para alumno nuevo.
- ADR-016 Adoptar dominio, workflow, perfil y tarifa server-side para solicitud de ubicacion.
- ADR-017 Permitir la verificacion publica de certificados mediante QR.
- ADR-018 Aplicar limites modulares y formato compartido a consulta de solicitudes.
- ADR-019 Aplicar limites modulares y API publica a consulta de ubicacion.
- ADR-020 Aplicar limites modulares y APIs publicas a solicitud de beca.
- ADR-021 Aplicar limites modulares y APIs publicas a solicitud de certificados.
- ADR-022 Aplicar limites modulares y APIs publicas a solicitud de constancias.
- ADR-023 Aplicar limites modulares y APIs publicas a solicitud de ubicacion.
- ADR-024 Aplicar limites modulares y APIs publicas a solicitud de alumno nuevo.
- ADR-025 Establecer gates automaticos de calidad y baselines temporales.
- ADR-026 Clasificar niveles de prueba y usar dobles deterministas.
- ADR-027 Simplificar la consulta publica de certificado sin capas ceremoniales.
- ADR-028 Mantener `shared` pequeno y orientado a capacidades estables.
- ADR-029 Aplicar una politica explicita por operacion y proposito en el BFF CIUNAC.
- ADR-030 Mantener limites pragmaticos entre seguridad transversal, BFF y features.

## 11. Riesgos y mitigaciones
- Riesgo: extraer demasiada logica a `shared`.
  Mitigacion: exigir uso transversal real y contrato estable.
- Riesgo: que application vuelva a depender de UI.
  Mitigacion: reglas ESLint iniciales y checklist de revision.
- Riesgo: que Zustand se convierta en cache global difusa.
  Mitigacion: separar catalogos, flujo y estado visual.
- Riesgo: servicios legacy sigan creciendo.
  Mitigacion: mantenerlos como fachada y mover nueva integracion a infrastructure.
- Riesgo: replay deliberado de una cookie OTP antigua.
  Mitigacion: limitacion documentada; migrar intentos y uso unico a Redis o persistencia backend.
- Riesgo: cuatro vulnerabilidades altas conocidas en dependencias de produccion.
  Mitigacion: baseline que vence el `2026-09-17` y actualizacion aislada de Next.js.
- Riesgo: axe no identifica todas las barreras de accesibilidad.
  Mitigacion: mantener revision manual con teclado, lector de pantalla, zoom y contraste.
- Riesgo: teardown de Playwright bloqueado en Windows y build dependiente de Google Fonts.
  Mitigacion: ejecutar CI en Ubuntu y planificar fuente local/reproducible.
- Riesgo: la sesion de consulta digital aun no demuestra propiedad del recurso por DNI.
  Mitigacion: crear un endpoint especializado o validacion backend antes de ampliar
  las operaciones disponibles sobre documentos.

## 12. Criterios de calidad
- Instalacion reproducible con `npm ci`.
- `npm run lint`, `npm run typecheck` y `npm run build` exitosos.
- Unitarias e integracion Vitest exitosas.
- Smoke E2E y accesibilidad automatizada exitosos antes del merge.
- Regresion E2E completa ejecutada en `main`, manualmente y por cron.
- Knip sin nuevos archivos, dependencias o imports no declarados.
- Auditoria sin vulnerabilidades criticas ni high nuevas; excepciones con vencimiento.
- Bundle cliente sin valores de secretos privados.
- Requisitos afectados vinculados con implementacion y pruebas en trazabilidad.
- Reglas de negocio puras en `domain` y componentes sin orquestacion HTTP directa.
