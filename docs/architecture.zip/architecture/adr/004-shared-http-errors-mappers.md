# ADR-004 Centralizar HTTP, errores y mappers

## Estado
Aceptado. Actualizado el 2026-08-31.

## Contexto
La integracion con API estaba repartida en `services/`, con payloads construidos cerca de la UI.

## Decision
Mantener infraestructura compartida minima:
- `AppError`
- funciones de transporte en `lib/api.service.ts`
- adaptadores sin estado para recursos y correo
- mappers `toRequestDTO`

## Consecuencias
- No se agrega una clase `HttpClient` sobre funciones que ya exponen el mismo
  contrato.
- Uploads simples consumen directamente el transporte y validan su respuesta en
  el limite.
- Nueva integracion debe preferir gateways y repositories.
- Los cambios de contrato API impactan primero en mappers e infrastructure.
