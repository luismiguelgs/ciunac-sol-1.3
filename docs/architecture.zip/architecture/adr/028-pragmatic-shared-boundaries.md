# ADR-028 Limites pragmaticos para `modules/shared`

## Estado

Aceptado el 2026-08-31.

## Contexto

`modules/shared` acumulaba tipos sin consumidores, un cache cliente para un texto
ya cargado en servidor y varias clases que delegaban sin transformar datos ni
proteger una frontera. Esa estructura aumentaba archivos e imports, pero no
reducía el acoplamiento ni mejoraba la capacidad de prueba.

## Decision

- Compartir solo capacidades usadas por varios features con contrato estable.
- Pasar catalogos ya resueltos por Server Components mediante props.
- Mantener un unico nivel de transporte HTTP en `lib/api.service.ts`; los
  adaptadores compartidos solo agregan semantica real.
- Evitar clases sin estado, factories y repositories que solo reenvian argumentos.
- Mantener validaciones comunes en Zod y reglas puras de archivos sin depender de
  tipos del navegador.
- No unificar componentes OTP, layouts o flujos por similitud visual mientras sus
  contratos y responsabilidades no sean equivalentes.

## Consecuencias

- `modules/shared` se reduce de 24 a 21 archivos y de 1061 a 976 lineas.
- El paso de pago deja de consultar `textos` en el navegador.
- La tabla de precios vuelve a ser Server Component.
- Se eliminan fachadas HTTP/storage redundantes y tipos legacy.
- Los features siguen siendo responsables de precios, textos, payloads y reglas
  posteriores al pago.
- Una futura extraccion debera demostrar consumidores reales y una API estable.
