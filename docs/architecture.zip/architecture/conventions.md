# Convenciones Arquitectonicas

## Capas
- `presentation`: UI, eventos, loading, errores visibles y navegacion.
- `application`: casos de uso y puertos.
- `domain`: reglas y tipos de negocio.
- `infrastructure`: gateways, DTOs, mappers y acceso a API.

Las capas son responsabilidades, no carpetas obligatorias. Un feature de lectura
simple puede omitir `application` cuando no existe orquestacion ni una politica de
caso de uso real. La excepcion debe quedar registrada mediante ADR y conservar
dominio puro, validacion en el limite externo y acceso HTTP server-only.

## Reglas de dependencia
- `presentation` depende de `application` y de componentes compartidos estables.
  En una consulta simple sin capa application puede depender directamente del
  modelo de dominio, pero nunca de HTTP o infraestructura.
- `application` puede depender de `domain` y de puertos.
- `infrastructure` implementa puertos de `application`.
- `domain` no depende de React, Next.js ni de servicios HTTP.

## API Publica de Features
- Un feature estabilizado expone sus consumidores browser-safe desde `index.ts`.
- La composicion exclusiva de servidor se expone desde `server.ts` con
  `import 'server-only'`.
- Rutas y otros features no deben importar carpetas internas de un feature que ya
  tenga API publica.
- `consulta-certificado` expone vista desde `index.ts` y consulta segura desde
  `server.ts`. ADR-027 documenta por que este slice no tiene capa `application`.
- `consulta-solicitud` expone presentacion desde `index.ts`, composicion de servidor
  desde `server.ts` y aplica limites de capas mediante ESLint.
- `consulta-ubicacion` expone su vista desde `index.ts`, el caso de uso compuesto
  desde `server.ts` y solo consume el contexto comun mediante
  `@/modules/consultas/server` dentro de infraestructura.
- `solicitud-beca` expone el wizard desde `index.ts`, la composicion cliente desde
  `client.ts` y catalogos/validacion de archivos desde `server.ts`.
- `solicitud-certificado` expone proceso y finalizacion desde `index.ts`, casos de
  uso compuestos del navegador desde `client.ts` y catalogos/validacion de precio
  desde `server.ts`.
- `solicitud-constancia` expone proceso y finalizacion desde `index.ts`, casos de
  uso compuestos del navegador desde `client.ts` y catalogos/validacion de precio
  desde `server.ts`.
- `solicitud-ubicacion` expone cronograma, proceso y finalizacion desde `index.ts`,
  casos de uso compuestos desde `client.ts` y catalogos, perfil y validaciones BFF
  desde `server.ts`.
- `solicitud-nuevo` expone el wizard desde `index.ts`, compone registro y reintento
  de correo desde `client.ts` y publica catalogos/validacion Q10 server-side desde
  `server.ts`.
- Los archivos `client.ts`/`client.tsx` y `server.ts` pueden actuar como composition roots; no
  contienen reglas de negocio y son los unicos puntos que conectan implementaciones
  de infraestructura con casos de uso.

## Estado
- Formularios: React Hook Form.
- Flujo multi-step: Zustand solo cuando el estado debe sobrevivir entre pasos.
- Catalogos: preferir server fetching; usar cache en cliente solo si hay una razon funcional clara.
- Catalogos persistidos: usar stores de solo lectura con `hasHydrated`, `setData` y `clearData`.
- Flujo multi-step: cada store debe exponer `reset` y reiniciarse al entrar al proceso.

## Mapa de estado
- `modules/solicitud-certificado/presentation/solicitud-certificado.store.ts`: workflow tipado de certificados.
- `modules/solicitud-constancia/presentation/solicitud-constancia.store.ts`: workflow tipado de constancias.
- `modules/solicitud-beca/presentation/solicitud-beca.store.ts`: workflow tipado del flujo de beca.
- `modules/solicitud-nuevo/presentation/new-student.store.ts`: workflow tipado del flujo de alumno nuevo.
- `modules/solicitud-ubicacion/presentation/solicitud-ubicacion.store.ts`: workflow tipado del flujo de ubicacion.
- Estados de submit, dialogos y loading: vivir en componentes o hooks de `presentation`.

## Criterios de extraccion a shared
- Debe existir en al menos dos features.
- Debe tener comportamiento equivalente, no solo UI parecida.
- Debe tener nombre y contrato estables.
- No se crea una clase, repository o hook si solo delega los mismos argumentos y
  resultado a otra funcion.
- Los puertos pueden expresarse como funciones inyectables cuando existe una sola
  operacion y no hay un contrato polimorfico adicional. La testabilidad no exige
  una interfaz y una clase por cada llamada.
- Los catalogos ya obtenidos en servidor se pasan como props; no se repiten en un
  store o fetch cliente sin una necesidad funcional demostrada.
- Un renderer compartido recibe datos ya resueltos; no decide titulos, precios,
  plazos ni reglas especificas de un feature.

## Verificacion obligatoria
- Ejecutar `npm run lint`.
- Ejecutar `npx tsc --noEmit`.
- Ejecutar `npm run build`.
